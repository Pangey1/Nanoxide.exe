                                                                              N                             A                                   N                                          O                                         X                                     I                                               D                                              E
My new GDI malware in C++
Compiled in Visual Studio 2026
Thanks for reading!